# plumber.R

# load model
modelo = base::readRDS("../outputs/glm.up.rds")

#* Echo back the input
#* @param msg The message to echo
#* @get /echo
function(msg=""){
  list(msg = paste0("The message is: '", msg, "'"))
}

#* Plot a histogram
#* @png
#* @get /plot
function(){
  rand <- rnorm(100000)
  hist(rand,breaks = 100)
}

#* Return the predicted
#* @param Married The first number to add
#* @param Education The second number to add
#* @param LoanAmount The second number to add
#* @param Credit_History The second number to add
#* @param Property_Area The second number to add
#* @post /prever
funcao_que_preve <- function(Married,Education,LoanAmount,Credit_History,Property_Area){
  

  # ordenando as colunas 
  input_data <<- data.frame(Married = factor(Married,levels = c("","No","Yes")),
                               Education = factor(Education,levels = c("Graduate","Not Graduate")),
                               LoanAmount = as.numeric(LoanAmount),
                               Credit_History = factor(Credit_History, levels = c("0","1")),
                               Property_Area = factor(Property_Area,levels = c("Rural","Semiurban","Urban")))
  
  # predict and return result
  pred <<- stats::predict(modelo, input_data)
  paste("----------------\nTest case predicted to be", as.character(pred), "\n----------------\n")
}



