library(tidyverse)
library(dplyr)
library(ggplot2movies)
## Loading tidyverse: ggplot2
## Loading tidyverse: tibble
## Loading tidyverse: tidyr
## Loading tidyverse: readr
## Loading tidyverse: purrr
## Loading tidyverse: dplyr
## Conflicts with tidy packages ----------------------------------------------
## filter(): dplyr, stats
## lag():    dplyr, stats
dados <- ggplot2movies::movies %>% 
                        filter(!is.na(budget), budget > 0) %>% 
                        dplyr::select(title,year,budget,rating) %>%
                        arrange(desc(year))

modelo <- lm(rating ~ budget + year, data = dados)


#* @post /prever
funcao_que_preve <- function(orcamento, ano) {
  d <- data.frame(budget = as.numeric(orcamento), year = as.numeric(ano))
  stats::predict(modelo, newdata = d)
}