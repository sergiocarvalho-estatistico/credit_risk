# plumber.R

suppressMessages(library(tidyverse))
suppressMessages(library(kernlab))

# load test and train data
df = base::readRDS("../outputs/test_data.rds")

# load model
model = base::readRDS("../outputs/glm.up.rds")

# take first test case for prediction
input_data <- df[1,]

# predict test case using model
pred <- predict(model, input_data)



cat("----------------\nTest case predicted to be", as.character(pred), "\n----------------")

## ----------------
## Test case predicted to be ckd 
## ----------------

#getwd()
#setwd("D:/Documentos/TestesdeEmprego/ONOVOLAB/aplication")